# Refined version of your face recognition program with better structure and features.

import cv2
import os
import tkinter as tk
from tkinter import Label
from skimage.metrics import structural_similarity as ssim
from PIL import Image, ImageTk
import sqlite3
from datetime import datetime

# Initialize database
DB_PATH = "PHOTOS.db"
IMAGES_DIR = "static/images"

def init_database():
    """Initialize SQLite database for storing photo records."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS photos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        photo_name TEXT,
        timestamp TEXT,
        match_status TEXT
    )
    """)
    conn.commit()
    conn.close()


def insert_photo_record(photo_name, match_status):
    """Insert a photo record into the database."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("INSERT INTO photos (photo_name, timestamp, match_status) VALUES (?, ?, ?)",
                   (photo_name, timestamp, match_status))
    conn.commit()
    conn.close()


def capture_photo(file_path):
    """Capture a photo from the webcam and save it to the specified path."""
    video_capture = cv2.VideoCapture(0)
    if not video_capture.isOpened():
        print("Error: Could not open webcam.")
        return False

    ret, frame = video_capture.read()
    if not ret:
        print("Error: Could not capture image.")
        return False

    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    cv2.imwrite(file_path, frame)
    print(f"Photo saved at {file_path}")

    video_capture.release()
    cv2.destroyAllWindows()
    return True


def detect_face(file_path):
    """Detect a face in the specified image file and return the face region."""
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    image = cv2.imread(file_path)
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray_image, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    if len(faces) == 0:
        print(f"No face detected in {file_path}")
        return None

    x, y, w, h = faces[0]
    return gray_image[y:y+h, x:x+w]


def compare_faces(reference_face, new_face):
    """Compare two face regions using Structural Similarity Index (SSIM)."""
    new_face_resized = cv2.resize(new_face, (reference_face.shape[1], reference_face.shape[0]))
    score, _ = ssim(reference_face, new_face_resized, full=True)
    print(f"SSIM score: {score}")
    return score > 0.5


def delete_file(file_path):
    """Delete a file if it exists."""
    try:
        os.remove(file_path)
        print(f"Deleted {file_path}")
    except Exception as e:
        print(f"Error deleting file {file_path}: {e}")


def capture_reference():
    """Capture the reference photo."""
    reference_photo_path = os.path.join(IMAGES_DIR, "reference_photo.jpg")
    if capture_photo(reference_photo_path):
        message_label.config(text="Reference photo captured successfully!", fg="green")
        show_image(reference_photo_path, reference_label)


def capture_and_prompt():
    """Capture a new photo and prompt for user choice."""
    global new_photo_path
    new_photo_path = os.path.join(IMAGES_DIR, f"new_photo_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg")
    if capture_photo(new_photo_path):
        show_image(new_photo_path, new_label)
        message_label.config(text="New photo captured for comparison. Choose an action:", fg="green")
        continue_button.pack(side="left", padx=10)
        cancel_button.pack(side="left", padx=10)


def continue_with_same_photo():
    """Proceed with face matching using the current new photo."""
    continue_button.pack_forget()
    cancel_button.pack_forget()
    compare_faces_with_reference(new_photo_path)


def cancel_and_capture_new():
    """Cancel current photo and capture a new one."""
    delete_file(new_photo_path)
    continue_button.pack_forget()
    cancel_button.pack_forget()
    message_label.config(text="Canceled. Please capture a new photo.", fg="blue")


def compare_faces_with_reference(new_photo_path):
    """Compare new photo with reference and log the result."""
    reference_face = detect_face(os.path.join(IMAGES_DIR, "reference_photo.jpg"))
    if reference_face is None:
        message_label.config(text="No face detected in the reference photo.", fg="red")
        return

    new_face = detect_face(new_photo_path)
    if new_face is None:
        message_label.config(text="No face detected in the new photo.", fg="red")
        return

    match = compare_faces(reference_face, new_face)
    match_status = "Matched" if match else "Not Matched"
    insert_photo_record(new_photo_path, match_status)

    if match:
        message_label.config(text="The faces match! Stopping capture.", fg="green")
        clear_photos()
    else:
        message_label.config(text="Faces do not match. Please try again.", fg="red")


def clear_photos():
    """Clear the displayed photos once a match is found."""
    reference_label.config(image='')
    reference_label.image = None
    new_label.config(image='')
    new_label.image = None


def show_image(image_path, label):
    """Display the captured image in the GUI."""
    img = Image.open(image_path)
    img = img.resize((200, 200))
    img = ImageTk.PhotoImage(img)
    label.config(image=img)
    label.image = img


def end_program():
    """Close the program."""
    window.destroy()

# Initialize database
init_database()

# Create GUI window
window = tk.Tk()
window.title("Face Recognition Application")
window.geometry("700x500")
window.config(bg="blue")

# Button frame
button_frame = tk.Frame(window, bg="blue")
button_frame.pack(pady=10)

capture_reference_button = tk.Button(button_frame, text="Capture Reference Photo", command=capture_reference)
capture_reference_button.pack(side="left", padx=20)

capture_new_button = tk.Button(button_frame, text="Capture New Photo", command=capture_and_prompt)
capture_new_button.pack(side="left", padx=20)

end_button = tk.Button(button_frame, text="END", command=end_program, bg="red", fg="white")
end_button.pack(side="left", padx=20)

# Photo frame
photo_frame = tk.Frame(window, bg="blue")
photo_frame.pack(pady=10)

reference_label = Label(photo_frame, bg="blue")
reference_label.pack(side="left", padx=20)

new_label = Label(photo_frame, bg="blue")
new_label.pack(side="left", padx=20)

# Message label
message_label = Label(window, text="", font=("Helvetica", 24), fg="red", bg="blue")
message_label.pack(pady=10)

# Action buttons
continue_button = tk.Button(window, text="Continue with Same Photo", command=continue_with_same_photo, fg="green")
cancel_button = tk.Button(window, text="Cancel and Capture New", command=cancel_and_capture_new, fg="red")

# Run the application
window.mainloop()
